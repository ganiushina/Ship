import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {


        Cargo cargo1 = new Cargo("food", 500);
        Cargo cargo2 = new Cargo("clothes", 300 );
        Cargo cargo3 = new Cargo("oil", 600 );

        ArrayList<Cargo> cargo = new ArrayList<Cargo>();
        cargo.add(cargo1);
        cargo.add(cargo2);
        cargo.add(cargo3);

        PortLoading pl = new PortLoading(cargo);

        final Distance distance = new Distance(60);


        PortuUloading pul = new PortuUloading();


        Ship ship1 = new Ship("Jonn", 200, pl, distance, pul);
        Ship ship2 = new Ship("Jeck", 100, pl, distance, pul);
        Ship ship3 = new Ship("Jonny", 300, pl, distance, pul);
        Ship ship4 = new Ship("Jim", 200, pl, distance, pul);
        Ship ship5 = new Ship("Bim", 400, pl, distance, pul);

        Thread t1 = new Thread(ship1);
        t1.start();
        Thread t2 = new Thread(ship2);
        t2.start();
        Thread t3 = new Thread(ship3);
        t3.start();
        Thread t4 = new Thread(ship4);
        t4.start();
        Thread t5 = new Thread(ship5);
        t5.start();



    }
}
