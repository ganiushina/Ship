import java.util.ArrayList;

public class Cargo { // Груз

    private String name;

    private ArrayList<String> type;
    private int weight;


    public String getName() {
        return name;
    }

    public Cargo(String value, int weight){
        this.name = value;
        this.weight = weight;

    }

    public Cargo getCargo(){
        return this;
    }

    public int getWeight(){
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }
}
