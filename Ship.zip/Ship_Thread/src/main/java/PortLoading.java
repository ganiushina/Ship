import java.util.ArrayList;
import java.util.HashMap;


public class PortLoading {  // погрузка

    private HashMap<Integer, Cargo> typeCargo = new HashMap<Integer, Cargo>();
    boolean isBusy = false;

    ArrayList<Thread> portSize = new ArrayList<Thread>();


    private ArrayList<Cargo> cargos;

    public PortLoading(ArrayList<Cargo> cargo){
        this.cargos =cargo;
        insTypeLoading();
    }

    public void insTypeLoading(){
        for (int i = 0; i <cargos.size() ; i++) {
            typeCargo.put(i, cargos.get(i));

            System.out.println(" Создали порт № " + (i+1) + " с товаром " + cargos.get(i).getName() + " объемом " + cargos.get(i).getWeight() );
        }
    }


    public void getCargo(Ship s) {
        for (int i = 0; i < typeCargo.size(); i++) {
            while (typeCargo.get(i).getWeight() > 0) {
             //   if (isBusy == false){
                    synchronized (typeCargo.get(i)) {

                        isBusy = true;
                        if (typeCargo.get(i).getWeight() > 0 && typeCargo.get(i).getWeight() >= s.getCapacity()) {
                            if (typeCargo.get(i).equals(s.getcargo()) == false) {
                                System.out.println(" Порт " + (i + 1) + " ожидает корабля");
                                try {
                                    Thread.sleep(2000);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }

                                System.out.println(" Порт номер " + (i + 1) + " занят." + " Загружается корабль " + s.getName());
                                System.out.println("Корабль " + s.getName() + " берет товар " + typeCargo.get(i).getName() + " весом " + s.getCapacity() + " из порта " + (i + 1));
                                s.putCargo(typeCargo.get(i), s.getCapacity());
                             //   putGoods(s, i);

                                typeCargo.get(i).setWeight(typeCargo.get(i).getWeight() - s.getCapacity());
                                System.out.println("В порту осталось  " + (i + 1) + " " + typeCargo.get(i).getWeight() + " " + typeCargo.get(i).getName());

                                try {
                                    Thread.sleep(1000);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                                break;


                            }
                            if (typeCargo.get(i).getWeight() <= s.getCapacity() && typeCargo.get(i).getWeight() != 0) {
                                System.out.println("Корабль " + s.getName() + " берет товар " + typeCargo.get(i).getName() + " весом " + typeCargo.get(i).getWeight());
                                s.putCargo(typeCargo.get(i), typeCargo.get(i).getWeight());
                                typeCargo.get(i).setWeight(0);
                                System.out.println("В порту " + (i + 1) + " осталось  " + 0);
                                try {
                                    Thread.sleep(1000);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                                break;

                            }
                            System.out.println(s.getName() + " освобождает порт ");
                        }
                    }
                s.dis.go(s);
           // }
            }
        }
    }

}
