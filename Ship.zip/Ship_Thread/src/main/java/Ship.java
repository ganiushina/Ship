public class Ship implements Runnable {

    private String name;
    private int capacity;

    PortLoading pl;
    PortuUloading pul;

    Distance dis;
    Cargo cargo;

    public int getCapacity() {
        return capacity;
    }

    public String getName() {
        return name;
    }

    public Ship(String name, int capacity, PortLoading pl, Distance dis, PortuUloading pul) {
        this.name = name;
        this.capacity = capacity;
        this.pl = pl;
        this.dis = dis;
        this.pul= pul;
    }

    public void putCargo(Cargo c, int weight){
        setCargo(c);
        System.out.println("В корабле  " + this.name + " лежит товар " + c.getName() + " весом  " + weight);
    }

    public Cargo getcargo() {
        return cargo;
    }

    public void setCargo(Cargo cargo) {
        this.cargo = cargo;
    }


    public void run() {
        pl.getCargo(this);
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


}
